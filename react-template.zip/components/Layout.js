import React, { Children } from 'react'
import Footer from './Footer'
import Header from './Header';
import Navbar from './Navbar'

const Layout = props => (
  <>
    {/* header */}
    <Header />
    {/* main content */}
    {props.children}
    {/* footer */}
    <Footer></Footer>
  </>
);


export default Layout;