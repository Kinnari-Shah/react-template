import React from 'react'
import Link from 'next/link'
import Image from 'next/image'

const Navbar = () => {
    return (
        <>
        <nav class="md:ml-auto flex flex-wrap items-center text-base justify-center">
            <Link href="/">
              <a className="mr-5 hover:text-gray-900 block mt-4 lg:inline-block lg:mt-0 text-xl text-red-800 font-normal hover:text-orange-500">
                Home
              </a>
            </Link>
            <Link href="/about">
              <a className="mr-5 hover:text-gray-900 block mt-4 lg:inline-block lg:mt-0 text-xl text-red-800 font-normal hover:text-orange-500">
                About
              </a>
            </Link>
            <Link href="/blogs">
              <a className="mr-5 hover:text-gray-900 block mt-4 lg:inline-block lg:mt-0 text-xl text-red-800 font-normal hover:text-orange-500">
                Blogs
              </a>
            </Link>
          </nav>
        </>
    )
}

export default Navbar